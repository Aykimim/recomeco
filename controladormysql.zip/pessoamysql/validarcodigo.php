<?php
$nome= $_POST['nome'];

	$numero = 20;
	$gera; 

	if($gera == $numero) {
		echo "Você venceu com o número: ".$numero;
	} else {
		echo "Você perdeu, tente novamente.";
        }
?>