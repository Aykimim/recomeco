<?php

$hostname = "localhost";
$usuario = "kimmim21_eykimim";
$senha = "abacaxi1804";
$bancodedados = "kimmim21_bancodedados";

$mysqli = mysqli_connect($hostname, $usuario, $senha, $bancodedados);
 /*
if ($mysqli) {
    echo "conectado ao banco de dados";
}
else {
    echo "Não foi possível conectar-se ao banco de dados:";
}

?>*/