<?php include 'header.php'; ?>
<div class="mb-3 mt-3">
<div class ="container min-vh-100">
	<div class="row ">
   <!-- margin-top: calc(2 * var(--bs-gutter-x));-->
    </br></br></br>
<h5>Aviso do site ao (a) visitante:</br></br>

    Ao ligar, informe que viu o profissional(a) no site Mão Amiga . Eles querem saber! 
    </br>
    Confirme também a rua e o número, pois o endereço anunciado nunca é o exato, mas apenas uma referência próxima.</br>
    Não nos envolvemos em tratativas de anunciantes e seus clientes, nem nos responsabilizamos por pagamentos antecipados!</br>
    Todo atendimento esperado deve ser alinhado com o anunciante antes do encontro.
    </br>
    Somente faça o contato via WhatsApp se o intuito for de realmente sair com o anunciante,
    </br>
    assim, desocupados com interesse em apenas puxar conversa, serão bloqueados.
    </br>
    </h5>
    </div>
</div>
</div>
    <?php include 'footer.php'; ?>