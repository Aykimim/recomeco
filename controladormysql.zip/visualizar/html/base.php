<?php include 'header.php'; ?>

<!--FIM do cabecario-->

<!--MEIO EM CIMA-->


<div class ="container">
  <div class = "row align-items-center justify-content-evenly">
    <div class= "col-md-6 display-4 fw-bold">
      <!--texto-->
      
      <h2>
        </br></br>
        &nbsp&nbsp Encontre</br>
        &nbsp&nbsp Profissionais</br>
        &nbsp&nbsp de Alto Padrão</br>
        </br></br>
      </h2>
      <!--FIM texto-->
    </div>
    <div class= "col-md-5">
      <!--BARRA DE PESQUISA-->
        <span id="divBusca">
          <form class="d-flex" role="search">
          <select class="form-select" aria-label="cidade" name="cidade" id="cidade">
        <option href="https://kimmim.shop/visualizar/html/exibeperfils.php?cidade=Manhuacu" >Manhuacu</option>
        <option href="https://kimmim.shop/visualizar/html/exibeperfils.php?cidade=Manhumirim" >Manhumirim</option>
        <option href="https://kimmim.shop/visualizar/html/exibeperfils.php?cidade=Simonesia" >Simonesia</option>
      </select>
            <!--<input class="form-control me-2 " type="search" placeholder="Pesquisa" aria-label="Search">-->
            <button class="btn btn-outline-success btn-info link-dark" type="Buscar">Buscar</button>
          </form>
        </span>
      </div>
      <!--FIM DA BARRA DE PESQUISA-->
    </div>
  </div>
</div>







<!--    cidades    -->

</br>
<side>
  <h5>
    <center>Estado de Minas Gerais</center>
  </h5>

  <div class="container px-4 text-center">
    <div class="rounded row gx-5">
      <div class="col">
        <div class=" img-thumbnail border bg-light"><a href="https://kimmim.shop/visualizar/html/exibeperfils.php?cidade=Manhuacu"><img src="/visualizar/img/manhuacu.png" class="img-fluid"></a></div>
        <figcaption class="figure-caption text-center">Manhuaçu</figcaption>
      </div>
      <div class="col">
        <div class="img-thumbnail border bg-light"><a href="https://kimmim.shop/visualizar/html/exibeperfils.php?cidade=Manhumirim"><img src="/visualizar/img/manhumirim.png" class="img-fluid"></div>
        <figcaption class="figure-caption text-center">Manhumirim</figcaption>
      </div>
      <div class="col">
        <div class="img-thumbnail border bg-light"><a href="https://kimmim.shop/visualizar/html/exibeperfils.php?cidade=Simonesia"> <img src="/visualizar/img/simonesia.png" class="img-fluid"></div>
        <figcaption class="figure-caption text-center">Simonesia</figcaption>
      </div>
    </div>
  </div>
  </br>
</side>


<!-- roda pe -->

<?php include 'footer.php'; ?>