<!-- roda pe -->




<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!--<div class="fixed-bottom">-->
  <footer>
    <div class="d-flex justify-content-center footer-content">

      <a href="/visualizar/html/base.php">
        <p> Mao amiga</p>
      </a>
      <ul class="socials">
        <li><a href="https://www.facebook.com/yasmim.dutra.9699?mibextid=ZbWKwL"><i class="fa fa-facebook"></i></a></li>
        <li><a href="https://mobile.twitter.com/eykimim18"><i class="fa fa-twitter"></i></a></li>
        <li><a href="https://br.linkedin.com/in/eykimim-pereira-4763841a2?trk=public_profile_samename-profile"><i class="fa fa-linkedin-square"></i></a></li>
        <li><a href="https://www.linkedin.com/in/yasmim-dutra-57747218b"><i class="fa fa-linkedin-square"></i></a></li>
      </ul>
    </div>

    <div class="d-flex justify-content-center footer-content  footer-bottom">
      <div class="footer-menu">
        <ul class="f-menu">
          <li><a href="/visualizar/html/base.php">Home</a></li>
          <li><a href="/visualizar/html/sobre.php">Sobre</a></li>
          <li><a href="/visualizar/html/contato.php">Contato</a></li>
          <li><a href="/visualizar/html/politica.php">Politica</a></li>
          <li><a href="/visualizar/html/anunciantes/cadastro.php">Anunciar</a></li>
        </ul>
      </div>
    </div>
    </style>
  </footer>
<!-- </div>-->
</body>



<!--FIM RODAPE-->