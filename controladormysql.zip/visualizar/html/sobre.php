<?php include 'header.php'; ?>
<div class="mb-3 mt-3">
	<div class="container min-vh-100">
		<div class="row">

			<h5></br></br>
				Nossa missão</br></br>
				No momento atual, se você não está na internet, você não existe com isso </br>
				a necessidade de ter uma rede social ou um web site se tornou fundamental para qualquer negócio,</br>
				principalmente para trabalhadores autônomos que em sua maioria não possui loja fixa.</br>
				Com isso em mente este projeto visa construir um espaço de negócios seguro para </br>
				trabalhadores autônomos.</br>
			</h5>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>